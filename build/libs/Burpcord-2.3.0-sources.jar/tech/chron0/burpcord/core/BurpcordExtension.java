package tech.chron0.burpcord.core;

import tech.chron0.burpcord.config.BurpcordConfig;
import tech.chron0.burpcord.discord.ActivityProvider;
import tech.chron0.burpcord.discord.DiscordRPCManager;
import tech.chron0.burpcord.listeners.*;
import tech.chron0.burpcord.listeners.providers.*;
import tech.chron0.burpcord.listeners.handlers.*;
import tech.chron0.burpcord.ui.BurpcordSettingsTab;

import burp.api.montoya.BurpExtension;
import burp.api.montoya.MontoyaApi;
import burp.api.montoya.extension.ExtensionUnloadingHandler;

import java.util.Arrays;
import java.util.List;

import javax.swing.SwingUtilities;

/**
 * <h1>Burpcord Extension</h1>
 * <p>
 * The main entry point for the Burpcord extension.
 * </p>
 * 
 * <h2>Overview</h2>
 * <p>
 * Burpcord integrates Discord Rich Presence into Burp Suite, allowing users to
 * share their security research status
 * and tool usage with colleagues or communities on Discord.
 * </p>
 * 
 * <h3>Features</h3>
 * <ul>
 * <li>Manage Discord Rich Presence connection.</li>
 * <li>Track activity across Proxy, Scanner, Repeater, Intruder, and more.</li>
 * <li>Customize presence status and details.</li>
 * </ul>
 * 
 * @author Jon Marien
 * @version 2.3.0
 * @see <a href="https://discord.gg/wXWJp9M9Cq">Burp Suite Discord</a>
 */
public class BurpcordExtension implements BurpExtension, ExtensionUnloadingHandler {

        private DiscordRPCManager rpcManager;

        @Override
        public void initialize(MontoyaApi api) {
                api.extension().setName("Burpcord");

                // Config
                BurpcordConfig config = new BurpcordConfig(api.persistence().preferences());

                // Core RPC Manager
                rpcManager = new DiscordRPCManager(config);

                // Initialize Components
                initializeComponents(api, config, rpcManager);

                // UI
                SwingUtilities.invokeLater(() -> {
                        BurpcordSettingsTab settingsTab = new BurpcordSettingsTab(api, config, rpcManager);
                        api.userInterface().registerSuiteTab("Burpcord", settingsTab);
                });

                // Register Unload
                api.extension().registerUnloadingHandler(this);

                logBanner();
                BurpcordSettingsTab.log("Burpcord v" + BurpcordConstants.VERSION + " loaded.");

                logEnabledFeatures(config);

                // Start RPC
                BurpcordSettingsTab.log("Initializing Discord RPC...");
                rpcManager.initialize();
        }

        @Override
        public void extensionUnloaded() {
                if (rpcManager != null) {
                        rpcManager.shutdown();
                }
                BurpcordSettingsTab.log("Burpcord unloaded.");
        }

        public static void logBanner() {
                BurpcordSettingsTab.log("========================================");
                BurpcordSettingsTab.log("   Burpcord - Discord RPC for Burp");
                BurpcordSettingsTab.log("========================================");
        }

        public static void logEnabledFeatures(BurpcordConfig config) {
                StringBuilder sb = new StringBuilder("Enabled Features: ");
                if (config.isShowIntercept())
                        sb.append("[Intercept] ");
                if (config.isShowScan())
                        sb.append("[Scanner] ");
                if (config.isShowProxy())
                        sb.append("[Proxy] ");
                if (config.isShowRepeater())
                        sb.append("[Repeater] ");
                if (config.isShowIntruder())
                        sb.append("[Intruder] ");
                BurpcordSettingsTab.log(sb.toString());
        }

        private void initializeComponents(MontoyaApi api, BurpcordConfig config, DiscordRPCManager rpcManager) {
                // Initialize all components - Priority is now defined within each class via
                // getPriority()
                List<ActivityProvider> components = Arrays.asList(
                                new BurpcordProxyHandler(config),
                                new BurpcordScannerListener(config),
                                new BurpcordRepeaterListener(config),
                                new BurpcordIntruderListener(config),
                                new BurpcordWebSocketListener(config),
                                new BurpcordSiteMapProvider(api, config),
                                new BurpcordScopeProvider(api, config),
                                new BurpcordCollaboratorProvider(api, config));

                // Register Providers (Manager handles sorting by priority)
                rpcManager.registerProviders(components);

                // Auto-register Burp Components
                for (ActivityProvider component : components) {
                        if (component instanceof BurpComponent) {
                                ((BurpComponent) component).register(api);
                        }
                }
        }
}
